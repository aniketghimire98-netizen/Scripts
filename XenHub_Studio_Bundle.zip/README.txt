Xen Hub Studio bundle

FILES
- XenHub_Studio_Client.lua: LocalScript with key gate, WindUI tabs, player/NPC targeting,
  player/NPC ESP, FOV circle, lock-on camera, and player teleport request UI.
- XenHub_Studio_Server.lua: Server Script that creates the RemoteEvent and authorizes
  teleport requests.

SETUP (YOUR OWN EXPERIENCE ONLY)
1. Install WindUI as a ModuleScript named `WindUI` inside ReplicatedStorage.
2. Put XenHub_Studio_Client.lua in StarterPlayer > StarterPlayerScripts as a LocalScript.
3. Put XenHub_Studio_Server.lua in ServerScriptService as a Script.
4. Tag NPC Models with CollectionService tag `AimTarget`; each needs a Humanoid and
   HumanoidRootPart (or Head).
5. Key is `Keyedesp`. This is only a client-side UI gate, not secure authentication.
6. For a user-owned experience, the creator account is authorized for teleport.
   For a group-owned experience, add your Roblox user ID to ADMIN_USER_IDS in the server script.

NOTES
- This is for a game you own/control, not for exploiting other people's games.
- WindUI must be installed as a ModuleScript in ReplicatedStorage. Standard Studio LocalScripts
  cannot use executor-only loadstring(game:HttpGet(...)) to fetch arbitrary code.
- The FOV circle is a visual targeting boundary; camera lock-on works only while the target
  is on-screen and within the circle.
