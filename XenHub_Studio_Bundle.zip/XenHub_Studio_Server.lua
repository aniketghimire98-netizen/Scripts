-- XenHub_Studio_Server.lua
-- Put this Script in ServerScriptService in YOUR OWN Roblox experience.
-- It creates the RemoteEvent and validates teleport requests on the server.
-- For user-owned experiences, the creator can request teleportation.
-- For group-owned experiences, add trusted user IDs to ADMIN_USER_IDS below.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ADMIN_USER_IDS = {
    -- [123456789] = true, -- Replace with your own Roblox UserId if group-owned.
}

local remote = ReplicatedStorage:FindFirstChild("XenTeleportRequest")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "XenTeleportRequest"
    remote.Parent = ReplicatedStorage
end

local lastRequest = {}

local function isAuthorized(player)
    if game.CreatorType == Enum.CreatorType.User and player.UserId == game.CreatorId then
        return true
    end
    return ADMIN_USER_IDS[player.UserId] == true
end

remote.OnServerEvent:Connect(function(player, targetUserId)
    if not isAuthorized(player) then
        warn(("Xen teleport denied for %s (%d): not authorized"):format(player.Name, player.UserId))
        return
    end

    if typeof(targetUserId) ~= "number" then return end
    if os.clock() - (lastRequest[player] or 0) < 2 then return end
    lastRequest[player] = os.clock()

    local target = Players:GetPlayerByUserId(targetUserId)
    if not target or target == player then return end

    local character = player.Character
    local targetCharacter = target.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    local targetRoot = targetCharacter and targetCharacter:FindFirstChild("HumanoidRootPart")
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")

    if not root or not targetRoot or not humanoid or humanoid.Health <= 0 then return end

    -- Place the authorized requester a few studs beside the target.
    character:PivotTo(targetRoot.CFrame * CFrame.new(4, 0, 0))
end)

Players.PlayerRemoving:Connect(function(player)
    lastRequest[player] = nil
end)
